"use strict";
/* Offline test: verifies exactly 15 unique commands, menu completeness,
   and that handlers respond honestly with a mock socket. No WhatsApp needed. */
const assert = require("assert");
const { COMMANDS, buildMenu, handleCommand } = require("../src/commands");
const cfgStore = require("../src/configStore");
const cfg = cfgStore.load();

assert.strictEqual(COMMANDS.length, 15, `Expected 15 commands, got ${COMMANDS.length}`);
const names = COMMANDS.map((c) => c.name);
assert.strictEqual(new Set(names).size, 15, "Command names must be unique");
const expected = ["ping","menu","autoreact","autostatusreact","ytdl","tiktokdl","fbdownload","onceview","autostatusview","song","naat","sticker","ai","owner","help"];
assert.deepStrictEqual([...names].sort(), [...expected].sort(), "Command set mismatch");

const menu = buildMenu(cfg);
for (const n of expected) assert.ok(menu.includes(`.${n}`), `Menu is missing .${n}`);
assert.ok(menu.includes(cfg.channelUrl), "Menu must include the WhatsApp channel");
assert.ok(menu.includes("ZUNI X HAMZI"), "Menu must include developer credit");

(async () => {
  const sent = [];
  const mockSock = { sendMessage: async (jid, content) => { sent.push(content); } };
  const base = { sock: mockSock, msg: {}, jid: "123@s.whatsapp.net", sender: "123", isOwnerUser: true, cfg, msgTimestamp: Math.floor(Date.now() / 1000) };
  const ctxFor = (command, args = []) => ({ ...base, command, args, reply: async (t) => { sent.push({ text: t }); } });

  await handleCommand(ctxFor("ping"));
  assert.ok(sent.at(-1).text.includes("Pong"), "ping should reply Pong");

  await handleCommand(ctxFor("onceview"));
  assert.ok(sent.at(-1).text.includes("will NOT"), "onceview must refuse bypassing");

  await handleCommand(ctxFor("owner"));
  assert.ok(sent.at(-1).text.includes("ZUNI X HAMZI"), "owner should show developer credit");

  await handleCommand(ctxFor("help"));
  assert.ok(sent.at(-1).text.includes(".ytdl"), "help should list commands");

  await handleCommand(ctxFor("doesnotexist"));
  assert.ok(sent.at(-1).text.includes("Unknown command"), "unknown command should give a useful error");

  await handleCommand(ctxFor("autoreact", ["on"]));
  assert.ok(sent.at(-1).text.includes("Auto React updated"), "owner should be able to enable autoreact");
  cfgStore.save({ autoReact: { enabled: false } });

  console.log("✅ All offline tests passed: 15 commands, menu complete, handlers respond.");
})().catch((e) => { console.error("❌ Test failed:", e); process.exit(1); });
