"use strict";
const $ = (id) => document.getElementById(id);
const token = () => localStorage.getItem("zhb_token") || "";
const headers = () => ({ "Content-Type": "application/json", "x-admin-token": token() });

/* Theme */
const savedTheme = localStorage.getItem("zhb_theme") || "dark";
document.documentElement.dataset.theme = savedTheme;
function syncThemeBtn(){ $("themeBtn").textContent = document.documentElement.dataset.theme === "dark" ? "☀️ Light theme" : "🌙 Dark theme"; }
syncThemeBtn();
$("themeBtn").onclick = () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next; localStorage.setItem("zhb_theme", next); syncThemeBtn();
};

/* Status polling — live from the server, never assumed */
async function refreshStatus() {
  try {
    const s = await (await fetch("/api/status")).json();
    const dot = $("statusDot"); dot.className = "dot " + s.status;
    const labels = { open: "🟢 Connected to WhatsApp", qr: "🟡 Waiting — scan the QR code", pairing: "🟡 Waiting — enter the pairing code", connecting: "🟡 Connecting…", disconnected: "🔴 Disconnected" };
    $("statusText").textContent = labels[s.status] || s.status;
    $("phonePill").textContent = s.phone ? "📱 " + s.phone : "";
    $("qrBox").classList.toggle("hidden", !(s.status === "qr" && s.qr));
    if (s.qr) $("qrImg").src = s.qr;
    $("pairBox").classList.toggle("hidden", !(s.pairingCode));
    if (s.pairingCode) $("pairCode").textContent = s.pairingCode;
    if (s.lastError) $("connHint").textContent = "⚠️ Last error: " + s.lastError;
    $("arEnabled").checked = !!s.settings.autoReact.enabled; $("arEmoji").value = s.settings.autoReact.emoji;
    $("asrEnabled").checked = !!s.settings.autoStatusReact.enabled; $("asrEmoji").value = s.settings.autoStatusReact.emoji;
    $("asvEnabled").checked = !!s.settings.autoStatusView.enabled;
  } catch { $("statusText").textContent = "🔴 Bot server not reachable — is `npm start` running?"; }
}
setInterval(refreshStatus, 3000); refreshStatus();

$("connectBtn").onclick = async () => {
  const r = await fetch("/api/connect", { method: "POST", headers: headers() });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) alert(d.error || "Connect failed. If a dashboard token is set, enter it in Owner settings first.");
  refreshStatus();
};
$("logoutBtn").onclick = async () => {
  if (!confirm("Logout and clear the WhatsApp session? You will need to scan/pair again.")) return;
  await fetch("/api/logout", { method: "POST", headers: headers() }); refreshStatus();
};
$("pairForm").onsubmit = async (e) => {
  e.preventDefault();
  const r = await fetch("/api/pair", { method: "POST", headers: headers(), body: JSON.stringify({ phone: $("pairPhone").value }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) alert(d.error || "Pairing failed"); refreshStatus();
};

/* Commands — loaded from the server so the list can never drift from the bot */
let allCommands = [];
async function loadCommands() {
  allCommands = await (await fetch("/api/commands")).json();
  $("cmdCount").textContent = allCommands.length + " commands";
  renderCommands("");
}
function renderCommands(filter) {
  $("cmdGrid").innerHTML = allCommands
    .filter((c) => (c.name + c.description + c.category).toLowerCase().includes(filter.toLowerCase()))
    .map((c) => `<div class="cmd"><b>${c.emoji} .${c.name}</b> <span class="pill">${c.category}</span><p>${c.description}</p><code>${c.usage}</code></div>`).join("")
    || '<p class="hint">No commands match.</p>';
}
$("cmdSearch").oninput = (e) => renderCommands(e.target.value);
loadCommands();

/* Settings */
async function saveSettings(extra = {}) {
  const body = {
    autoReact: { enabled: $("arEnabled").checked, emoji: $("arEmoji").value || "❤️" },
    autoStatusReact: { enabled: $("asrEnabled").checked, emoji: $("asrEmoji").value || "🔥" },
    autoStatusView: { enabled: $("asvEnabled").checked },
    ...extra
  };
  const r = await fetch("/api/settings", { method: "POST", headers: headers(), body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  $("settingsMsg").textContent = r.ok ? "✅ Settings saved. They apply immediately in WhatsApp too." : "❌ " + (d.error || "Save failed");
  refreshStatus();
}
$("saveSettingsBtn").onclick = () => saveSettings();
$("saveOwnerBtn").onclick = () => {
  localStorage.setItem("zhb_token", $("dashToken").value.trim());
  saveSettings({ owner: { name: $("ownerName").value, numbers: $("ownerNumbers").value, contactText: $("ownerText").value } });
};
(async () => {
  try {
    const c = await (await fetch("/api/config-public")).json();
    $("ownerName").value = c.owner.name || "ZUNI X HAMZI";
    $("ownerNumbers").value = (c.owner.numbers || []).join(", ");
    $("ownerText").value = c.owner.contactText || "";
    $("dashToken").value = token();
  } catch {}
})();

/* Song / naat search */
let searchType = "song";
document.querySelectorAll(".tab").forEach((t) => t.onclick = () => {
  document.querySelectorAll(".tab").forEach((x) => x.classList.remove("active"));
  t.classList.add("active"); searchType = t.dataset.type;
});
$("searchForm").onsubmit = async (e) => {
  e.preventDefault();
  const q = $("searchQ").value.trim(); if (!q) return;
  $("searchResults").innerHTML = '<p class="hint">Searching…</p>';
  try {
    const d = await (await fetch(`/api/search?type=${searchType}&q=${encodeURIComponent(q)}`)).json();
    if (d.error) throw new Error(d.error);
    $("searchResults").innerHTML = d.results.map((r) =>
      `<div class="result">${r.thumbnail ? `<img src="${r.thumbnail}" alt="">` : ""}<div><a href="${r.url}" target="_blank" rel="noopener">${r.title}</a><p>⏱️ ${r.duration || "-"} · 👁️ ${r.views || "-"} · ${r.author || ""}</p></div></div>`).join("")
      || '<p class="hint">No results found.</p>';
  } catch (err) { $("searchResults").innerHTML = `<p class="hint">❌ ${err.message}</p>`; }
};

/* Logs */
async function loadLogs() {
  try {
    const logs = await (await fetch("/api/logs")).json();
    $("logs").innerHTML = logs.map((l) => `<div class="log"><time>${new Date(l.time).toLocaleTimeString()}</time><span class="t-${l.type}">[${l.type}]</span><span>${l.message.replace(/</g, "&lt;")}</span></div>`).join("") || '<p class="hint">No activity yet.</p>';
  } catch {}
}
setInterval(loadLogs, 5000); loadLogs();
