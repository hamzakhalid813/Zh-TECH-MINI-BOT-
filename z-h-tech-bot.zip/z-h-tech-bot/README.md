# 🤖 Z+H TECH BOT

**All-in-one WhatsApp Bot** — Dashboard + real WhatsApp connection + exactly **15 commands**
**Powered by ZUNI X HAMZI**
📢 **Official WhatsApp Channel:** https://whatsapp.com/channel/0029Vb9BC9I9mrGbxn3GW70R

![ZH TECH logo](public/assets/logo.webp)

---

## ⚠️ Read this first — how the WhatsApp connection works (honest notes)

- This project connects with **Baileys** (`@whiskeysockets/baileys`), the widely-used
  WhatsApp **Web** (linked-device) integration. That is what makes QR/pairing,
  statuses, reactions and stickers possible.
- The **official WhatsApp Business Platform (Cloud API)** cannot do linked-device
  features like viewing/reacting to statuses, so it is *not* used here. Baileys is
  an unofficial integration: use a **separate/secondary number** for the bot,
  expect WhatsApp to occasionally require re-linking, and follow WhatsApp's terms.
  Accounts that spam can be restricted by WhatsApp — this bot sends nothing unsolicited.
- The dashboard status and QR code are **real**: the QR is generated live by the
  server from WhatsApp's linking flow. Nothing is faked — if the bot is not
  connected, the dashboard says *Disconnected*.
- **`.onceview` does NOT bypass View Once.** It only explains View Once and the
  safe alternatives. Capturing View Once media would violate the sender's privacy.
- Downloaders/search depend on third-party services that can go offline or
  rate-limit. When that happens the bot replies with the **real error** —
  it never invents a download link.

---

## 🚀 Installation (mobile-friendly: works in Termux too)

### 1) Requirements
- Node.js **18+** (Termux: `pkg install nodejs git` … on a PC/server: nodejs.org)

### 2) Install
```bash
cd z-h-tech-bot
npm install
# Optional, only for direct YouTube sending in .ytdl:
npm install @distube/ytdl-core
```

### 3) Configure
```bash
cp .env.example .env
```
Edit `.env`:
| Variable | Required | Purpose |
|---|---|---|
| `OWNER_NUMBERS` | **Yes** | Your WhatsApp number(s), country code, digits only (e.g. `923001234567`). Controls owner-only settings and `.owner`. |
| `PORT` | No | Dashboard port (default `3000`) |
| `DASHBOARD_TOKEN` | Recommended | Protects connect/settings/logout API calls from the dashboard |
| `AI_API_KEY` | Only for `.ai` | Any OpenAI-compatible provider key. Without it, `.ai` honestly replies “not configured”. |
| `AI_BASE_URL`, `AI_MODEL` | No | Provider endpoint / model |
| `DOWNLOADER_API_URL` | Only for FB / as TikTok backup | Your provider URL with `{url}` placeholder, e.g. `https://provider.example/api?url={url}`. `.fbdownload` needs this; without it, it explains that clearly. |
| `DOWNLOADER_API_KEY` | No | Sent as a Bearer token to your downloader provider |
| `ALLOW_YT_DOWNLOAD` | No | `false` makes `.ytdl` info+link only |

Your own uploaded logo: replace `public/assets/logo.webp` with your logo file
(keep the same filename). In this delivered project it is already set to the
previously created **ZH TECH logo** — the same file is used in the dashboard
and sent as the image with `.menu`.

### 4) Run
```bash
npm start
```
Open **http://localhost:3000**, then:
- **QR:** press **Connect / Show QR** → scan in WhatsApp → *Linked devices*.
- **Pairing code:** enter your number → press **Get pairing code** → in WhatsApp
  choose *Link with phone number instead* and enter the code shown.

The session is saved in `auth_info/` (git-ignored). You only pair once;
on disconnect the bot auto-reconnects with backoff. **Logout** (dashboard)
logs out and deletes the session.

### 5) Use in WhatsApp
Message the linked number (from another phone, or a group it is in): `.menu`

---

## 📋 The 15 commands (exactly 15)

| # | Command | Description |
|---|---|---|
| 1 | `.ping` | Check bot response time and connection status |
| 2 | `.menu` | All 15 commands + categories + ZH TECH logo image |
| 3 | `.autoreact` | Auto reactions to messages — `on/off/<emoji>` (owner changes) |
| 4 | `.autostatusreact` | Auto reactions to statuses — `on/off/<emoji>` (owner changes) |
| 5 | `.ytdl` | YouTube info/download for eligible content you own/licensed |
| 6 | `.tiktokdl` | TikTok download via a real provider (TikWM public API or your configured API) |
| 7 | `.fbdownload` | Public Facebook video via your configured downloader API |
| 8 | `.onceview` | View Once explainer — **does not bypass View Once privacy** |
| 9 | `.autostatusview` | Auto status viewing — `on/off` (owner changes) |
| 10 | `.song` | Song search (title/artist) with real YouTube listening links |
| 11 | `.naat` | Naat search (title/reciter) with real listening links |
| 12 | `.sticker` | Make a 512×512 sticker from an image (caption or reply) |
| 13 | `.ai` | AI answers (needs `AI_API_KEY`) |
| 14 | `.owner` | Owner contact + developer credit **ZUNI X HAMZI** |
| 15 | `.help` | Usage, examples, permissions, troubleshooting (`.help ytdl`) |

Commands are case-insensitive (`.PING`, `.Menu` work). Unknown commands get a
helpful error pointing to `.menu`.

---

## 🖥️ Dashboard features
Live connection status + real QR + pairing code • Connect / Logout •
Command directory (loaded from the server, always exactly in sync) •
Auto-react / status automation toggles • Song & naat search •
Owner configuration • Recent activity & error logs •
WhatsApp Channel button • Dark/light theme (saved in the browser) • Mobile-first

Dashboard APIs: `GET /api/status`, `GET /api/commands`, `GET /api/logs`,
`GET /api/search?type=song|naat&q=…`, `POST /api/connect`, `POST /api/pair`,
`POST /api/settings`, `POST /api/logout` (token-protected when `DASHBOARD_TOKEN` is set).

## 🧪 Test (no WhatsApp needed)
```bash
npm test
```
Verifies exactly 15 unique commands, that `.menu` contains all 15 + the channel
link + developer credit, and that key handlers (ping / onceview / owner / help /
autoreact / unknown-command errors) respond correctly with a mock socket.

## 📁 Project structure
```
z-h-tech-bot/
├─ package.json            dependencies & scripts
├─ .env.example            copy to .env — secrets live ONLY here
├─ config/settings.json    non-secret bot settings (edited by dashboard/commands)
├─ public/                 dashboard (HTML/CSS/JS)
│  ├─ index.html  style.css  app.js
│  └─ assets/logo.webp     ZH TECH logo (dashboard + .menu image)
├─ src/
│  ├─ index.js             Express server + dashboard APIs
│  ├─ whatsapp.js          Baileys connection, QR/pairing, reconnect, logout, message router
│  ├─ commands.js          THE 15 commands + menu builder
│  ├─ configStore.js       settings load/save + owner check
│  └─ services/
│     ├─ media.js          YouTube search/info, TikTok/Facebook downloaders (honest errors)
│     └─ ai.js             OpenAI-compatible AI client
├─ scripts/test-commands.js
└─ auth_info/              WhatsApp session (auto-created, never share/commit)
```

## 🌍 Deployment notes
- Run on any VPS / Render / Railway / a home PC with `npm start` (keep the
  `auth_info/` folder persistent, or you must re-pair after every restart).
- Put the dashboard behind HTTPS and set `DASHBOARD_TOKEN` if it is public.
- Never commit `.env` or `auth_info/` — both are in `.gitignore`.

## 🔐 Security
API keys are read only from server-side `.env`. The dashboard never sees them.
Owner-only changes are checked against `OWNER_NUMBERS` on every command.

---
**Z+H TECH BOT — Powered by ZUNI X HAMZI**
📢 https://whatsapp.com/channel/0029Vb9BC9I9mrGbxn3GW70R
