"use strict";
const fs = require("fs");
const path = require("path");

const CONFIG_PATH = path.join(__dirname, "..", "config", "settings.json");

const DEFAULTS = {
  botName: "Z+H TECH BOT",
  developer: "ZUNI X HAMZI",
  channelUrl: "https://whatsapp.com/channel/0029Vb9BC9I9mrGbxn3GW70R",
  prefix: ".",
  autoReact: { enabled: false, emoji: "❤️", ownerOnlyChange: true },
  autoStatusReact: { enabled: false, emoji: "🔥" },
  autoStatusView: { enabled: false },
  owner: {
    name: process.env.OWNER_NAME || "ZUNI X HAMZI",
    numbers: (process.env.OWNER_NUMBERS || "")
      .split(",").map((s) => s.trim().replace(/\D/g, "")).filter(Boolean),
    contactText: process.env.OWNER_CONTACT_TEXT || "Developer: ZUNI X HAMZI"
  }
};

function deepMerge(base, extra) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(extra || {})) {
    if (v && typeof v === "object" && !Array.isArray(v) && base[k]) out[k] = deepMerge(base[k], v);
    else if (v !== undefined) out[k] = v;
  }
  return out;
}

let cache = null;
function load() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
    cache = deepMerge(DEFAULTS, raw);
  } catch { cache = structuredClone(DEFAULTS); }
  // Env owner numbers always win when provided (secrets/identity stay in env)
  const envOwners = (process.env.OWNER_NUMBERS || "").split(",").map((s) => s.trim().replace(/\D/g, "")).filter(Boolean);
  if (envOwners.length) cache.owner.numbers = envOwners;
  return cache;
}
function save(next) {
  cache = deepMerge(load(), next);
  fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cache, null, 2));
  return cache;
}
function isOwner(jidOrNumber) {
  const num = String(jidOrNumber || "").split("@")[0].split(":")[0].replace(/\D/g, "");
  return load().owner.numbers.includes(num);
}
module.exports = { load, save, isOwner, DEFAULTS, CONFIG_PATH };
