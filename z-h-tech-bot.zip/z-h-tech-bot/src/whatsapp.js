"use strict";
const path = require("path");
const fs = require("fs");
const configStore = require("./configStore");
const { handleCommand } = require("./commands");

const AUTH_DIR = path.join(__dirname, "..", "auth_info");
const logs = []; // ring buffer, newest last
function log(type, message) {
  const entry = { time: new Date().toISOString(), type, message: String(message).slice(0, 500) };
  logs.push(entry); if (logs.length > 200) logs.shift();
  console.log(`[${type}] ${entry.message}`);
}

const state = {
  status: "disconnected", // disconnected | connecting | qr | pairing | open
  qrDataUrl: null, pairingCode: null, phone: null,
  sock: null, reconnectAttempts: 0, lastError: null, startedAt: null
};

async function startWhatsApp({ pairingPhone = null } = {}) {
  // Lazy-require Baileys so `node --check` / unit tests work before npm install
  const baileys = require("@whiskeysockets/baileys");
  const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = baileys;
  const QRCode = require("qrcode");
  const pino = require("pino");

  if (state.sock) { try { state.sock.end(); } catch {} state.sock = null; }
  state.status = "connecting"; state.qrDataUrl = null; state.pairingCode = null; state.lastError = null;

  const { state: authState, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion().catch(() => ({ version: [2, 3000, 0] }));

  const sock = makeWASocket({
    version, auth: authState, logger: pino({ level: "silent" }),
    printQRInTerminal: false, browser: ["Z+H TECH BOT", "Chrome", "1.0.0"],
    markOnlineOnConnect: true
  });
  state.sock = sock;
  sock.ev.on("creds.update", saveCreds);

  if (pairingPhone && !authState.creds.registered) {
    state.status = "pairing";
    setTimeout(async () => {
      try {
        state.pairingCode = await sock.requestPairingCode(pairingPhone.replace(/\D/g, ""));
        log("pairing", `Pairing code requested for ${pairingPhone}: ${state.pairingCode}`);
      } catch (e) { state.lastError = e.message; log("error", `Pairing failed: ${e.message}`); }
    }, 2500);
  }

  sock.ev.on("connection.update", async (u) => {
    const { connection, lastDisconnect, qr } = u;
    if (qr && !pairingPhone) {
      state.status = "qr";
      state.qrDataUrl = await QRCode.toDataURL(qr).catch(() => null);
      log("qr", "New QR code generated — scan it from the dashboard or WhatsApp > Linked devices.");
    }
    if (connection === "open") {
      state.status = "open"; state.qrDataUrl = null; state.pairingCode = null;
      state.reconnectAttempts = 0; state.startedAt = new Date().toISOString();
      state.phone = sock.user?.id?.split("@")[0] || null;
      log("open", `Connected as ${state.phone || "unknown number"}`);
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      state.status = "disconnected"; state.qrDataUrl = null;
      log("close", `Connection closed (code ${code || "?"}). ${loggedOut ? "Logged out — session cleared." : "Will reconnect…"}`);
      if (loggedOut) { fs.rmSync(AUTH_DIR, { recursive: true, force: true }); state.sock = null; return; }
      const delay = Math.min(30000, 2000 * ++state.reconnectAttempts);
      setTimeout(() => startWhatsApp().catch((e) => log("error", `Reconnect failed: ${e.message}`)), delay);
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      try { await handleMessage(sock, msg); }
      catch (e) { log("error", `Message handler: ${e.message}`); }
    }
  });
  return sock;
}

async function handleMessage(sock, msg) {
  const cfg = configStore.load();
  const jid = msg.key.remoteJid || "";
  const isStatus = jid === "status@broadcast";
  const sender = msg.key.participant || jid;
  const isOwnerUser = configStore.isOwner(sender) || !!msg.key.fromMe;

  const m = msg.message || {};
  const text = m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || "";

  // ---- Status automation (only statuses) ----
  if (isStatus) {
    if (cfg.autoStatusView.enabled) {
      await sock.readMessages([msg.key]).catch((e) => log("error", `Status view failed: ${e.message}`));
    }
    if (cfg.autoStatusReact.enabled) {
      await sock.sendMessage(jid, { react: { text: cfg.autoStatusReact.emoji, key: msg.key } })
        .catch((e) => log("error", `Status react not supported/failed: ${e.message}`));
    }
    return;
  }
  if (msg.key.fromMe && !text.startsWith(cfg.prefix)) { /* own messages: still allow own commands below */ }

  // ---- Auto react to normal incoming messages ----
  const trimmed = text.trim();
  const isCommand = trimmed.startsWith(cfg.prefix);
  if (cfg.autoReact.enabled && !msg.key.fromMe && !isCommand) {
    await sock.sendMessage(jid, { react: { text: cfg.autoReact.emoji, key: msg.key } })
      .catch((e) => log("error", `Auto react failed: ${e.message}`));
  }
  if (!isCommand) return;

  const body = trimmed.slice(cfg.prefix.length).trim();
  const [rawCmd, ...args] = body.split(/\s+/);
  const command = (rawCmd || "").toLowerCase();
  log("command", `.${command} from ${sender.split("@")[0]}`);

  const quoted = m.extendedTextMessage?.contextInfo?.quotedMessage
    || m.imageMessage?.contextInfo?.quotedMessage || null;
  const quotedKey = m.extendedTextMessage?.contextInfo
    ? { remoteJid: jid, id: m.extendedTextMessage.contextInfo.stanzaId, participant: m.extendedTextMessage.contextInfo.participant }
    : null;

  await handleCommand({
    sock, msg, jid, sender, isOwnerUser, cfg, args, command,
    msgTimestamp: msg.messageTimestamp || Math.floor(Date.now() / 1000),
    quotedMsg: quoted, quotedKey,
    reply: (t) => sock.sendMessage(jid, { text: t }, { quoted: msg })
  });
}

async function logout() {
  if (state.sock) { try { await state.sock.logout(); } catch {} try { state.sock.end(); } catch {} }
  state.sock = null; state.status = "disconnected"; state.qrDataUrl = null; state.pairingCode = null;
  fs.rmSync(AUTH_DIR, { recursive: true, force: true });
  log("logout", "Logged out and session cleared.");
}

module.exports = { startWhatsApp, logout, state, logs, log };
