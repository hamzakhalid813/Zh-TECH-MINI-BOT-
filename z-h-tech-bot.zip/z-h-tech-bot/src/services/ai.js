"use strict";
/** AI answers via any OpenAI-compatible API. Key stays on the backend (.env). */
async function askAI(prompt) {
  const key = process.env.AI_API_KEY;
  if (!key) throw new Error("AI is not configured. The owner needs to set AI_API_KEY in the bot server .env file.");
  const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = process.env.AI_MODEL || "gpt-4o-mini";
  const res = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "You are Z+H TECH BOT, a helpful WhatsApp assistant by ZUNI X HAMZI. Reply briefly and clearly." },
        { role: "user", content: prompt }
      ],
      max_tokens: 600
    }),
    signal: AbortSignal.timeout(30000)
  });
  if (!res.ok) throw new Error(`AI provider returned HTTP ${res.status}. Check AI_API_KEY / AI_MODEL.`);
  const data = await res.json();
  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("AI provider returned an empty answer.");
  return text;
}
module.exports = { askAI };
