"use strict";
/**
 * Media search + download helpers.
 * Rules (important):
 * - Search uses yt-search (YouTube public search) and returns real watch links.
 * - Downloads are attempted only through a real provider/library.
 * - On ANY failure this module throws with a human reason. Callers must show
 *   that error to the user. It NEVER invents a download link.
 */

async function searchYouTube(query, limit = 5) {
  const yts = require("yt-search");
  const r = await yts(query);
  const videos = (r.videos || []).slice(0, limit);
  return videos.map((v) => ({
    title: v.title, url: v.url, duration: v.timestamp, views: v.views,
    author: v.author && v.author.name ? v.author.name : "", thumbnail: v.thumbnail
  }));
}

function isYouTubeUrl(u = "") { return /(youtube\.com|youtu\.be)/i.test(u); }
function isTikTokUrl(u = "") { return /tiktok\.com/i.test(u); }
function isFacebookUrl(u = "") { return /(facebook\.com|fb\.watch)/i.test(u); }

async function fetchJson(url, opts = {}) {
  const res = await fetch(url, { ...opts, signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`Provider returned HTTP ${res.status}`);
  return res.json();
}

/** Generic configured provider: DOWNLOADER_API_URL with {url} placeholder.
 *  Expected JSON shape from provider: { downloadUrl | url | data:{downloadUrl} } */
async function viaConfiguredProvider(url) {
  const tpl = process.env.DOWNLOADER_API_URL;
  if (!tpl) return null;
  const api = tpl.replace("{url}", encodeURIComponent(url));
  const data = await fetchJson(api, {
    headers: process.env.DOWNLOADER_API_KEY ? { Authorization: `Bearer ${process.env.DOWNLOADER_API_KEY}` } : {}
  });
  const link = data.downloadUrl || data.url || (data.data && (data.data.downloadUrl || data.data.url));
  if (!link) throw new Error("Downloader provider responded without a download URL.");
  return { downloadUrl: link, title: data.title || (data.data && data.data.title) || "" };
}

/** YouTube info + (optional, library-based) audio/video stream URL is NOT a
 *  public link, so .ytdl returns video info + the real YouTube watch link and,
 *  when ytdl-core is installed and download is allowed, the caller streams the
 *  file directly to WhatsApp instead of handing out a fake link. */
async function youtubeInfo(url) {
  if (!isYouTubeUrl(url)) throw new Error("That is not a YouTube link. Send a youtube.com or youtu.be link.");
  let ytdl = null;
  try { ytdl = require("@distube/ytdl-core"); } catch { /* optional dep */ }
  if (!ytdl) {
    // Still useful and honest: search-based info fallback
    const results = await searchYouTube(url, 1).catch(() => []);
    return { title: results[0]?.title || "YouTube video", url, streamable: false,
      note: "Install the optional @distube/ytdl-core package (npm i @distube/ytdl-core) to enable direct sending, or open the YouTube link." };
  }
  if (!ytdl.validateURL(url)) throw new Error("YouTube link could not be validated.");
  const info = await ytdl.getInfo(url);
  return { title: info.videoDetails.title, url: info.videoDetails.video_url,
    duration: info.videoDetails.lengthSeconds, streamable: process.env.ALLOW_YT_DOWNLOAD !== "false", _ytdl: ytdl };
}

async function tiktokDownload(url) {
  if (!isTikTokUrl(url)) throw new Error("That is not a TikTok link. Send a tiktok.com link.");
  const configured = await viaConfiguredProvider(url);
  if (configured) return configured;
  // Public TikWM API (third-party, may rate-limit or go offline -> honest error)
  const data = await fetchJson(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);
  const play = data && data.data && (data.data.play || data.data.wmplay);
  if (!play) throw new Error("TikTok downloader service returned no playable file. Try again later or configure DOWNLOADER_API_URL in .env.");
  return { downloadUrl: play, title: data.data.title || "TikTok video" };
}

async function facebookDownload(url) {
  if (!isFacebookUrl(url)) throw new Error("That is not a Facebook link. Send a public facebook.com or fb.watch link.");
  const configured = await viaConfiguredProvider(url);
  if (configured) return configured;
  throw new Error("No Facebook downloader is configured. Set DOWNLOADER_API_URL (with {url}) in .env to a provider you have an account with. Private/restricted Facebook videos cannot be downloaded.");
}

module.exports = { searchYouTube, youtubeInfo, tiktokDownload, facebookDownload, isYouTubeUrl, isTikTokUrl, isFacebookUrl };
