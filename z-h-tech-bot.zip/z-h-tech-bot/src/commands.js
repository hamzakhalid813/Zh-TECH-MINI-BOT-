"use strict";
const path = require("path");
const fs = require("fs");
const configStore = require("./configStore");
const media = require("./services/media");
const { askAI } = require("./services/ai");

const LOGO_PATH = path.join(__dirname, "..", "public", "assets", "logo.webp");
const startTime = Date.now();

function onOff(v) { return v ? "ON ✅" : "OFF ❌"; }
function footer(cfg) { return `\n\n_⚡ ${cfg.botName} | Powered by ${cfg.developer}_\n📢 Channel: ${cfg.channelUrl}`; }

/* ------------------------------------------------------------------ */
/*  EXACTLY 15 COMMANDS — do not add/remove without updating the menu  */
/* ------------------------------------------------------------------ */
const COMMANDS = [
  {
    name: "ping", category: "General", emoji: "🏓",
    description: "Check bot response time and connection status.",
    usage: ".ping",
    async handler(ctx) {
      const ms = Date.now() - ctx.msgTimestamp * 1000;
      const up = Math.floor((Date.now() - startTime) / 1000);
      await ctx.reply(`🏓 *Pong!*\n⚡ Response: *${Math.max(ms, 1)}ms*\n🟢 Status: *Connected*\n⏱️ Uptime: *${Math.floor(up / 60)}m ${up % 60}s*${footer(ctx.cfg)}`);
    }
  },
  {
    name: "menu", category: "General", emoji: "📋",
    description: "Display all 15 commands with descriptions, categories and the ZH TECH logo.",
    usage: ".menu",
    async handler(ctx) {
      const text = buildMenu(ctx.cfg);
      if (fs.existsSync(LOGO_PATH)) {
        await ctx.sock.sendMessage(ctx.jid, { image: fs.readFileSync(LOGO_PATH), caption: text }, { quoted: ctx.msg });
      } else {
        await ctx.reply(text + "\n\n_(Logo placeholder: add your logo at public/assets/logo.webp)_");
      }
    }
  },
  {
    name: "autoreact", category: "Automation", emoji: "❤️",
    description: "Enable/disable automatic reactions to incoming messages, with a configurable emoji (owner only to change).",
    usage: ".autoreact on | .autoreact off | .autoreact ❤️ | .autoreact (status)",
    async handler(ctx) {
      const cfg = ctx.cfg; const arg = (ctx.args[0] || "").toLowerCase();
      if (!arg) return ctx.reply(`❤️ *Auto React:* ${onOff(cfg.autoReact.enabled)}\nEmoji: ${cfg.autoReact.emoji}\n\nChange (owner only): \`.autoreact on\`, \`.autoreact off\`, \`.autoreact 👍\``);
      if (!ctx.isOwnerUser) return ctx.reply("⛔ Only the bot owner can change auto-react settings.");
      if (arg === "on") configStore.save({ autoReact: { enabled: true } });
      else if (arg === "off") configStore.save({ autoReact: { enabled: false } });
      else configStore.save({ autoReact: { emoji: ctx.args[0] } });
      const n = configStore.load();
      await ctx.reply(`✅ *Auto React updated*\nStatus: ${onOff(n.autoReact.enabled)} | Emoji: ${n.autoReact.emoji}`);
    }
  },
  {
    name: "autostatusreact", category: "Automation", emoji: "🔥",
    description: "Configure automatic reactions to WhatsApp statuses (owner only to change).",
    usage: ".autostatusreact on | off | <emoji>",
    async handler(ctx) {
      const cfg = ctx.cfg; const arg = (ctx.args[0] || "").toLowerCase();
      if (!arg) return ctx.reply(`🔥 *Auto Status React:* ${onOff(cfg.autoStatusReact.enabled)}\nEmoji: ${cfg.autoStatusReact.emoji}\n\nNote: WhatsApp/Baileys support for reacting to statuses can vary by account/version. If it is unavailable, the bot logs it instead of pretending it worked.`);
      if (!ctx.isOwnerUser) return ctx.reply("⛔ Only the bot owner can change this setting.");
      if (arg === "on") configStore.save({ autoStatusReact: { enabled: true } });
      else if (arg === "off") configStore.save({ autoStatusReact: { enabled: false } });
      else configStore.save({ autoStatusReact: { emoji: ctx.args[0] } });
      const n = configStore.load();
      await ctx.reply(`✅ *Auto Status React updated*\nStatus: ${onOff(n.autoStatusReact.enabled)} | Emoji: ${n.autoStatusReact.emoji}`);
    }
  },
  {
    name: "ytdl", category: "Download", emoji: "▶️",
    description: "Get info / download an eligible YouTube video you own or that is licensed for download.",
    usage: ".ytdl <youtube link>",
    async handler(ctx) {
      const url = ctx.args[0];
      if (!url) return ctx.reply("❌ Usage: `.ytdl <youtube link>`\nOnly download content you own or that is licensed for downloading.");
      try {
        const info = await media.youtubeInfo(url);
        if (info.streamable && info._ytdl && process.env.ALLOW_YT_DOWNLOAD !== "false") {
          await ctx.reply(`⬇️ Sending: *${info.title}*\nPlease wait…`);
          const stream = info._ytdl(url, { quality: "lowestvideo", filter: "audioandvideo" });
          const chunks = []; for await (const c of stream) chunks.push(c);
          const buf = Buffer.concat(chunks);
          if (buf.length > 60 * 1024 * 1024) throw new Error("Video is larger than WhatsApp's practical 60MB sending limit.");
          await ctx.sock.sendMessage(ctx.jid, { video: buf, caption: `▶️ *${info.title}*\n${info.url}${footer(ctx.cfg)}` }, { quoted: ctx.msg });
        } else {
          await ctx.reply(`▶️ *${info.title}*\n🔗 Watch: ${info.url}\n${info.note ? "ℹ️ " + info.note : ""}${footer(ctx.cfg)}`);
        }
      } catch (e) { await ctx.reply(`❌ YouTube download failed: ${e.message}`); }
    }
  },
  {
    name: "tiktokdl", category: "Download", emoji: "🎵",
    description: "Process an eligible TikTok video link using a supported downloader service.",
    usage: ".tiktokdl <tiktok link>",
    async handler(ctx) {
      const url = ctx.args[0];
      if (!url) return ctx.reply("❌ Usage: `.tiktokdl <tiktok link>`");
      try {
        const r = await media.tiktokDownload(url);
        await ctx.sock.sendMessage(ctx.jid, { video: { url: r.downloadUrl }, caption: `🎵 *${r.title || "TikTok video"}*${footer(ctx.cfg)}` }, { quoted: ctx.msg });
      } catch (e) { await ctx.reply(`❌ TikTok download failed: ${e.message}`); }
    }
  },
  {
    name: "fbdownload", category: "Download", emoji: "📘",
    description: "Process an eligible public Facebook video link using a configured downloader service.",
    usage: ".fbdownload <facebook link>",
    async handler(ctx) {
      const url = ctx.args[0];
      if (!url) return ctx.reply("❌ Usage: `.fbdownload <public facebook link>`");
      try {
        const r = await media.facebookDownload(url);
        await ctx.sock.sendMessage(ctx.jid, { video: { url: r.downloadUrl }, caption: `📘 *${r.title || "Facebook video"}*${footer(ctx.cfg)}` }, { quoted: ctx.msg });
      } catch (e) { await ctx.reply(`❌ Facebook download failed: ${e.message}`); }
    }
  },
  {
    name: "onceview", category: "Privacy", emoji: "👁️",
    description: "Explains WhatsApp View Once media. This bot does NOT bypass View Once privacy protections.",
    usage: ".onceview",
    async handler(ctx) {
      await ctx.reply(
`👁️ *WhatsApp View Once — Safe Explanation*

View Once photos/videos are designed to disappear after one viewing. They are a *privacy protection* chosen by the sender.

✅ What you can do:
• Ask the sender to resend it as a normal photo/video.
• Ask the sender to turn off View Once before sending.

⛔ What this bot will NOT do:
• It does not save, forward, screenshot-bypass or recover View Once media.
• Bypassing View Once violates the sender's privacy and WhatsApp's terms.

If someone sent you media by mistake, the safe option is to tell them — not to capture it.${footer(ctx.cfg)}`);
    }
  },
  {
    name: "autostatusview", category: "Automation", emoji: "👀",
    description: "Configure automatic status viewing where supported by the WhatsApp integration (owner only to change).",
    usage: ".autostatusview on | off",
    async handler(ctx) {
      const cfg = ctx.cfg; const arg = (ctx.args[0] || "").toLowerCase();
      if (!arg) return ctx.reply(`👀 *Auto Status View:* ${onOff(cfg.autoStatusView.enabled)}\n\nChange (owner only): \`.autostatusview on\` / \`.autostatusview off\``);
      if (!ctx.isOwnerUser) return ctx.reply("⛔ Only the bot owner can change this setting.");
      configStore.save({ autoStatusView: { enabled: arg === "on" } });
      await ctx.reply(`✅ *Auto Status View:* ${onOff(arg === "on")}`);
    }
  },
  {
    name: "song", category: "Media Search", emoji: "🎧",
    description: "Search songs by title, artist or keywords and return real listening links.",
    usage: ".song <song name / artist>",
    async handler(ctx) {
      const q = ctx.args.join(" ");
      if (!q) return ctx.reply("❌ Usage: `.song <song name>` — example: `.song tum hi ho`");
      try {
        const results = await media.searchYouTube(q + " official audio", 5);
        if (!results.length) return ctx.reply("😔 No songs found for that search. Try different keywords.");
        const lines = results.map((r, i) => `*${i + 1}. ${r.title}*\n⏱️ ${r.duration || "-"} | 👁️ ${r.views || "-"}\n🔗 ${r.url}`).join("\n\n");
        await ctx.reply(`🎧 *Songs for:* ${q}\n\n${lines}${footer(ctx.cfg)}`);
      } catch (e) { await ctx.reply(`❌ Song search failed: ${e.message}`); }
    }
  },
  {
    name: "naat", category: "Media Search", emoji: "🌙",
    description: "Search naats by title, reciter or keywords and return real listening links.",
    usage: ".naat <naat name / reciter>",
    async handler(ctx) {
      const q = ctx.args.join(" ");
      if (!q) return ctx.reply("❌ Usage: `.naat <naat name>` — example: `.naat Mustafa Jaan e Rehmat`");
      try {
        const results = await media.searchYouTube(q + " naat", 5);
        if (!results.length) return ctx.reply("😔 No naats found for that search. Try different keywords.");
        const lines = results.map((r, i) => `*${i + 1}. ${r.title}*\n⏱️ ${r.duration || "-"} | 👁️ ${r.views || "-"}\n🔗 ${r.url}`).join("\n\n");
        await ctx.reply(`🌙 *Naats for:* ${q}\n\n${lines}${footer(ctx.cfg)}`);
      } catch (e) { await ctx.reply(`❌ Naat search failed: ${e.message}`); }
    }
  },
  {
    name: "sticker", category: "Tools", emoji: "🖼️",
    description: "Create a sticker from an image you send (or reply to) with the caption .sticker.",
    usage: "Send/reply to an image with caption: .sticker",
    async handler(ctx) {
      try {
        const { downloadMediaMessage } = require("@whiskeysockets/baileys");
        const target = ctx.msg.message?.imageMessage ? ctx.msg
          : ctx.quotedMsg ? { key: ctx.quotedKey, message: ctx.quotedMsg } : null;
        if (!target) return ctx.reply("❌ Send an image with caption `.sticker`, or reply to an image with `.sticker`.");
        const buffer = await downloadMediaMessage(target, "buffer", {}, { logger: console });
        const sharp = require("sharp");
        const webp = await sharp(buffer).resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp().toBuffer();
        await ctx.sock.sendMessage(ctx.jid, { sticker: webp }, { quoted: ctx.msg });
      } catch (e) { await ctx.reply(`❌ Sticker failed: ${e.message}. Make sure you used a normal JPG/PNG image.`); }
    }
  },
  {
    name: "ai", category: "Tools", emoji: "🤖",
    description: "Ask the AI a question (requires AI_API_KEY configured by the owner on the server).",
    usage: ".ai <your question>",
    async handler(ctx) {
      const q = ctx.args.join(" ");
      if (!q) return ctx.reply("❌ Usage: `.ai <your question>`");
      try { await ctx.reply(`🤖 ${await askAI(q)}${footer(ctx.cfg)}`); }
      catch (e) { await ctx.reply(`❌ AI unavailable: ${e.message}`); }
    }
  },
  {
    name: "owner", category: "General", emoji: "👑",
    description: "Display the bot owner's configured contact information and developer credit.",
    usage: ".owner",
    async handler(ctx) {
      const o = ctx.cfg.owner;
      const numbers = o.numbers.length ? o.numbers.map((n) => `https://wa.me/${n}`).join("\n") : "Not configured yet (owner: set OWNER_NUMBERS in .env)";
      await ctx.reply(`👑 *Bot Owner*\n🧑‍💻 Developer: *${ctx.cfg.developer}*\n📝 ${o.contactText}\n📱 Contact:\n${numbers}${footer(ctx.cfg)}`);
    }
  },
  {
    name: "help", category: "General", emoji: "❓",
    description: "Command usage, examples, permissions and troubleshooting.",
    usage: ".help | .help <command>  e.g. .help ytdl",
    async handler(ctx) {
      const name = (ctx.args[0] || "").toLowerCase().replace(/^\./, "");
      const cmd = COMMANDS.find((c) => c.name === name);
      if (cmd) return ctx.reply(`❓ *Help: .${cmd.name}*\n${cmd.emoji} ${cmd.description}\n📌 Usage: \`${cmd.usage}\`\n📂 Category: ${cmd.category}`);
      const lines = COMMANDS.map((c) => `• \`.${c.name}\` — ${c.description}`).join("\n");
      await ctx.reply(
`❓ *${ctx.cfg.botName} — Help*

${lines}

🔐 *Permissions:* Automation settings (.autoreact, .autostatusreact, .autostatusview) can only be *changed* by the owner.
🛠️ *Troubleshooting:*
• No reply? Check the bot is connected (dashboard / .ping).
• Download failed? The link may be private, restricted, or the provider offline — the bot shows the real error, never a fake link.
• .ai not working? Owner must set AI_API_KEY in .env.
• Sticker failed? Use a normal JPG/PNG image.
Full list: send \`.menu\`${footer(ctx.cfg)}`);
    }
  }
];

function buildMenu(cfg) {
  const byCat = {};
  for (const c of COMMANDS) (byCat[c.category] ||= []).push(c);
  let n = 0;
  const sections = Object.entries(byCat).map(([cat, cmds]) =>
    `\n╭─ 📂 *${cat}*\n` + cmds.map((c) => `│ ${++n}. ${c.emoji} \`.${c.name}\`\n│    ${c.description}`).join("\n") + "\n╰────────────"
  ).join("\n");
  return `🤖 *${cfg.botName}*
_⚡ Powered by ${cfg.developer}_

👋 Assalam-o-Alaikum! Here are all *${COMMANDS.length} commands*:
${sections}

📢 *Follow Our WhatsApp Channel:*
${cfg.channelUrl}

_Type \`.help <command>\` for examples, e.g. \`.help ytdl\`_`;
}

async function handleCommand(ctx) {
  const cmd = COMMANDS.find((c) => c.name === ctx.command);
  if (!cmd) {
    await ctx.reply(`❌ Unknown command: \`.${ctx.command}\`\nType \`.menu\` to see all ${COMMANDS.length} commands, or \`.help\` for help.`);
    return false;
  }
  await cmd.handler(ctx);
  return true;
}

module.exports = { COMMANDS, buildMenu, handleCommand, LOGO_PATH };
