"use strict";
require("dotenv").config();
const path = require("path");
const express = require("express");
const configStore = require("./configStore");
const { COMMANDS } = require("./commands");
const wa = require("./whatsapp");
const media = require("./services/media");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

// Dashboard actions that change state require DASHBOARD_TOKEN when it is set.
function requireToken(req, res, next) {
  const token = process.env.DASHBOARD_TOKEN;
  if (!token) return next();
  if (req.headers["x-admin-token"] === token || req.query.token === token) return next();
  return res.status(401).json({ error: "Dashboard token required. Enter it in Settings, or set the x-admin-token header." });
}

app.get("/api/status", (req, res) => {
  const cfg = configStore.load();
  res.json({
    botName: cfg.botName, developer: cfg.developer, channelUrl: cfg.channelUrl,
    status: wa.state.status, phone: wa.state.phone, qr: wa.state.qrDataUrl,
    pairingCode: wa.state.pairingCode, lastError: wa.state.lastError,
    startedAt: wa.state.startedAt, commandsCount: COMMANDS.length,
    settings: { autoReact: cfg.autoReact, autoStatusReact: cfg.autoStatusReact, autoStatusView: cfg.autoStatusView }
  });
});

app.get("/api/commands", (req, res) => {
  res.json(COMMANDS.map(({ name, category, emoji, description, usage }) => ({ name, category, emoji, description, usage })));
});

app.get("/api/logs", (req, res) => res.json(wa.logs.slice(-80).reverse()));

app.get("/api/search", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const type = req.query.type === "naat" ? "naat" : "song";
  if (!q) return res.status(400).json({ error: "Missing ?q=" });
  try {
    const results = await media.searchYouTube(q + (type === "naat" ? " naat" : " official audio"), 6);
    res.json({ type, query: q, results });
  } catch (e) { res.status(502).json({ error: `Search failed: ${e.message}` }); }
});

app.post("/api/connect", requireToken, async (req, res) => {
  try { await wa.startWhatsApp(); res.json({ ok: true, status: wa.state.status }); }
  catch (e) { wa.log("error", e.message); res.status(500).json({ error: e.message }); }
});

app.post("/api/pair", requireToken, async (req, res) => {
  const phone = String(req.body?.phone || "").replace(/\D/g, "");
  if (phone.length < 10) return res.status(400).json({ error: "Enter a full phone number with country code, e.g. 923001234567" });
  try { await wa.startWhatsApp({ pairingPhone: phone }); res.json({ ok: true, note: "Pairing code will appear in /api/status within a few seconds." }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/logout", requireToken, async (req, res) => { await wa.logout(); res.json({ ok: true }); });

app.post("/api/settings", requireToken, (req, res) => {
  const b = req.body || {};
  const patch = {};
  if (b.autoReact) patch.autoReact = { enabled: !!b.autoReact.enabled, emoji: String(b.autoReact.emoji || "❤️").slice(0, 8) };
  if (b.autoStatusReact) patch.autoStatusReact = { enabled: !!b.autoStatusReact.enabled, emoji: String(b.autoStatusReact.emoji || "🔥").slice(0, 8) };
  if (b.autoStatusView) patch.autoStatusView = { enabled: !!b.autoStatusView.enabled };
  if (b.owner) patch.owner = {
    name: String(b.owner.name || "ZUNI X HAMZI").slice(0, 60),
    contactText: String(b.owner.contactText || "").slice(0, 200),
    numbers: (Array.isArray(b.owner.numbers) ? b.owner.numbers : String(b.owner.numbers || "").split(","))
      .map((s) => String(s).replace(/\D/g, "")).filter(Boolean)
  };
  const saved = configStore.save(patch);
  wa.log("settings", "Settings updated from dashboard.");
  res.json({ ok: true, settings: { autoReact: saved.autoReact, autoStatusReact: saved.autoStatusReact, autoStatusView: saved.autoStatusView, owner: saved.owner } });
});

app.get("/api/config-public", (req, res) => {
  const cfg = configStore.load();
  res.json({ owner: { name: cfg.owner.name, contactText: cfg.owner.contactText, numbers: cfg.owner.numbers } });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  wa.log("server", `Z+H TECH BOT dashboard: http://localhost:${PORT}`);
  if (process.env.AUTO_CONNECT !== "false") {
    wa.startWhatsApp().catch((e) => wa.log("error", `Initial connect failed: ${e.message}. Open the dashboard and press Connect after running npm install.`));
  } else {
    wa.log("server", "AUTO_CONNECT=false — open the dashboard and press Connect.");
  }
});
